import os

current_path = os.path.abspath(os.path.dirname(__file__))
database = os.path.join(current_path, "soft_mock.db")
